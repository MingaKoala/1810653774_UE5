package Aufgabe_1;

public class Main {


    public static void main(String[] args) {
        Mensch a = new Mensch ("Bene",24,"m");
        System.out.println(a.printAll());
    }
}

